package com.cg.dao;

import java.util.Map;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;

public interface BankDao {
	long addDetails(AccountBean account);
	Map<Long,AccountBean> accountDetails(AccountBean account);
	long addDeposit(long accountNo,long depositAmount);
	long addWithDraw(long accountNo,long withDrawAmount);
	 double balanceCheck();
	 long fundDetails(long accountNo,long fundAmount);
	 int addTransaction(TransactionBean transaction);
	 Map<Integer, TransactionBean> transactionDetails(TransactionBean transaction);
}
