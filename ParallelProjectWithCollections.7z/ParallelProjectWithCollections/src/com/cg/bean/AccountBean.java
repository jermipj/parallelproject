package com.cg.bean;

public class AccountBean {
	
	
	private long accountNo;
	private double balance;
	private String customerName;
	private long mobileNumber;
	public AccountBean(long accountNo, double balance, String customerName, long mobileNumber) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
	}
	public AccountBean() {
		super();
	
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "AccountBean [accountNo=" + accountNo + ", balance=" + balance + ", customerName=" + customerName
				+ ", mobileNumber=" + mobileNumber + "]";
	}
	

}
