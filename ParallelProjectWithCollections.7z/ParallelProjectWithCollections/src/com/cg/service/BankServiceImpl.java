package com.cg.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.bean.AccountBean;
import com.cg.bean.TransactionBean;
import com.cg.dao.BankDao;
import com.cg.dao.BankDaoImpl;
import com.cg.exception.BankException;

public class BankServiceImpl implements BankService{

	BankDao dao=new BankDaoImpl();
	
	@Override
	public boolean validateName(String name) throws BankException {

		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new BankException("First Letter should be Capital and Length should be greater than 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}
	@Override
	public boolean validateGender(String gender) throws BankException {
		boolean resultFlag=false;
		if(gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female")) {
			resultFlag = true;
		}else {
			
			throw new BankException("Gender should be only Male or Female");
		}
		return resultFlag;
	}
	@Override
	public boolean validateBalance(double balance) throws BankException{
		boolean resultFlag=false;
		if(balance<0) {
			throw new BankException("Balance should be greater than Zero");
		}else {
			resultFlag=true;
		}
		return resultFlag;
		
	}

	@Override
	public long addDetails(AccountBean account) {
		long accountNo=(long)(Math.random()*100000000);
		account.setAccountNo(accountNo);
		
		return dao.addDetails(account);
	}

	@Override
	public Map<Long, AccountBean> accountDetails(AccountBean account) {
		
		return dao.accountDetails(account);
	}

	@Override
	public long addDeposit(long accountNo, long depositAmount) {
		
		return dao.addDeposit(accountNo, depositAmount);
	}

	@Override
	public long addWithDraw(long accountNo, long withDrawAmount) {
		
		return dao.addWithDraw(accountNo, withDrawAmount);
	}

	@Override
	public double balanceCheck() {
		
		return dao.balanceCheck();
	}

	@Override
	public long fundDetails(long accountNo, long fundAmount) {
		
		return dao.fundDetails(accountNo, fundAmount);
	}

	@Override
	public int addTransaction(TransactionBean transaction) {
		int id=(int)(Math.random()*1000);
		transaction.setTransactionId(id);
		return dao.addTransaction(transaction);
	}

	@Override
	public Map<Integer, TransactionBean> transactionDetails(TransactionBean transaction) {
		
		return dao.transactionDetails(transaction);
	}
	
}
