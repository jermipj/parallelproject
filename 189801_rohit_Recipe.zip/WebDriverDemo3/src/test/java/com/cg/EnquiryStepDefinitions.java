package com.cg;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.pagemodel.CoachingClassEnquiryPage;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EnquiryStepDefinitions {
	
	WebDriver driver;
	CoachingClassEnquiryPage enquiryPage;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\BDD1\\WebDriverDemo3\\driver and pages\\chromedriver.exe");
		driver= new ChromeDriver();
		enquiryPage= new CoachingClassEnquiryPage(driver);
	}
	
	@After
	public void closeDriver() {
		driver.close();
	}
	
	@Given("^user is on enquiry page$")
	public void user_is_on_enquiry_page() throws Throwable {
		driver.get("D:\\BDD1\\WebDriverDemo3\\driver and pages\\Coaching_Class_Enquiry.html");
	}

	@Then("^heading should be present on the page$")
	public void heading_should_be_present_on_the_page() throws Throwable {
		String heading ="Shree Coaching Classes Enquiry";
		String pagesource= driver.getPageSource();
		   assertTrue(pagesource.contains(heading));

	}

	@Given("^user is on hotelbooking page$")
	public void user_is_on_hotelbooking_page() throws Throwable {
		driver.get("D:\\BDD1\\WebDriverDemo3\\driver and pages\\Coaching_Class_Enquiry.html");
	}

	@Then("^text should be present on the page$")
	public void text_should_be_present_on_the_page() throws Throwable {
		String text ="Tuition Enquiry Details Form";
		String pagesource= driver.getPageSource();
		   assertTrue(pagesource.contains(text));
	}

	@When("^user proceeds without entering firstname$")
	public void user_proceeds_without_entering_firstname() throws Throwable {
		enquiryPage.firstName.sendKeys(Keys.TAB);
	}

	@Then("^error message for firstname field should be displayed$")
	public void error_message_for_firstname_field_should_be_displayed() throws Throwable {
		String exp = "First Name must be filled out";
		String actual= driver.switchTo().alert().getText();
		assertEquals(actual, exp);
		driver.switchTo().alert().accept();
	}

	@When("^user proceeds without entering lastname$")
	public void user_proceeds_without_entering_lastname() throws Throwable {
		enquiryPage.setFirstName("ABC");
		enquiryPage.lastName.sendKeys(Keys.TAB);
	}

	@Then("^error message for lastname field should be displayed$")
	public void error_message_for_lastname_field_should_be_displayed() throws Throwable {
		String exp = "Last Name must be filled out";
		String actual= driver.switchTo().alert().getText();
		assertEquals(actual, exp);
		driver.switchTo().alert().accept();
	}

	@When("^user proceeds without entering email$")
	public void user_proceeds_without_entering_email() throws Throwable {
		enquiryPage.setFirstName("ABC");
		enquiryPage.setLastName("XYX");
		enquiryPage.email.sendKeys(Keys.TAB);
	}

	@Then("^error message for email field should be displayed$")
	public void error_message_for_email_field_should_be_displayed() throws Throwable {
		String exp = "Email must be filled out";
		String actual= driver.switchTo().alert().getText();
		assertEquals(actual, exp);
		driver.switchTo().alert().accept();
	}

	@When("^user proceeds entering mobileno$")
	public void user_proceeds_entering_mobileno() throws Throwable {
		enquiryPage.setFirstName("ABC");
		enquiryPage.setLastName("XYZ");
		enquiryPage.setEmail("abc@gmail.com");
		enquiryPage.mobileno.sendKeys(Keys.TAB);
	}

	@Then("^error message for mobileNo field should be displayed$")
	public void error_message_for_mobileNo_field_should_be_displayed() throws Throwable {
		String exp = "Mobile must be filled out";
		String actual= driver.switchTo().alert().getText();
		assertEquals(actual, exp);
		driver.switchTo().alert().accept();
	}

	@When("^user proceeds entering numeric mobile no$")
	public void user_proceeds_entering_numeric_mobile_no() throws Throwable {
		enquiryPage.setFirstName("ABC");
		enquiryPage.setLastName("XYZ");
		enquiryPage.setEmail("abc@gmail.com");
		enquiryPage.setMobileNo("sfsfafaaa");
		enquiryPage.tutionType.sendKeys(Keys.TAB);
	}

	@Then("^error message for numeric mobileno field should be displayed$")
	public void error_message_for_numeric_mobileno_field_should_be_displayed() throws Throwable {
		String exp = "Enter numeric value";
		String actual= driver.switchTo().alert().getText();
		assertEquals(actual, exp);
		driver.switchTo().alert().accept();
	}

	@When("^user proceeds entering valid mobile no$")
	public void user_proceeds_entering_valid_mobile_no() throws Throwable {
		enquiryPage.setFirstName("ABC");
		enquiryPage.setLastName("XYZ");
		enquiryPage.setEmail("abc@gmail.com");
		enquiryPage.setMobileNo("987654321");
		enquiryPage.clickButton();
	}

	@Then("^error message for valid mobileno field should be displayed$")
	public void error_message_for_valid_mobileno_field_should_be_displayed() throws Throwable {
		String exp = "Enter 10 digit Mobile number";
		String actual= driver.switchTo().alert().getText();
		assertEquals(actual, exp);
		driver.switchTo().alert().accept();
	}

	@When("^user proceeds without selecting tution type$")
	public void user_proceeds_without_selecting_tution_type() throws Throwable {
		//skipped
	}

	@Then("^error message for tution type field should be displayed$")
	public void error_message_for_tution_type_field_should_be_displayed() throws Throwable {
		//skipped
	}

	@When("^user proceeds without selecting city$")
	public void user_proceeds_without_selecting_city() throws Throwable {
		//skipped
	}

	@Then("^error message for city field should be displayed$")
	public void error_message_for_city_field_should_be_displayed() throws Throwable {
		//skipped
	}

	@When("^user proceeds without entering mode of learning$")
	public void user_proceeds_without_entering_mode_of_learning() throws Throwable {
		//skipped
	}

	@Then("^error message for mode of learning field should be displayed$")
	public void error_message_for_mode_of_learning_field_should_be_displayed() throws Throwable {
		//skipped
	}

	@When("^user clicks on submit request without entering enquiry details$")
	public void user_clicks_on_submit_request_without_entering_enquiry_details() throws Throwable {
		enquiryPage.setFirstName("ABC");
		enquiryPage.setLastName("XYZ");
		enquiryPage.setEmail("abc@gmail.com");
		enquiryPage.setMobileNo("9876543210");
		enquiryPage.clickButton();
	}

	@Then("^error message for enquiry details field should be displayed$")
	public void error_message_for_enquiry_details_field_should_be_displayed() throws Throwable {
		String exp = "Enquiry details must be filled out";
		String actual= driver.switchTo().alert().getText();
		assertEquals(actual, exp);
		driver.switchTo().alert().accept();
	}

	@When("^user enters all correct data and clicks submit request button$")
	public void user_enters_all_correct_data_and_clicks_submit_request_button() throws Throwable {
		enquiryPage.setFirstName("ABC");
		enquiryPage.setLastName("XYZ");
		enquiryPage.setEmail("abc@gmail.com");
		enquiryPage.setMobileNo("9876543210");
		enquiryPage.setenquiryDetails("enquiry");
		enquiryPage.clickButton();
	}

	@Then("^success message should be displayed$")
	public void success_message_should_be_displayed() throws Throwable {
		String exp = "Thank you for submitting the online coaching Class Enquiry";
		String actual= driver.switchTo().alert().getText();
		assertEquals(actual, exp);
		driver.switchTo().alert().accept();
	}

	@Then("^see off message should be displayed$")
	public void see_off_message_should_be_displayed() throws Throwable {
		String exp = "Our Counselor will contact you soon";
		driver.switchTo().alert().accept();
		String pagesource= driver.getPageSource();
		   assertTrue(pagesource.contains(exp));
	}

}
