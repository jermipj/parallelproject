package com.cg.pagemodel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CoachingClassEnquiryPage {
	
	public CoachingClassEnquiryPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}
	
		@FindBy(name="fname")
		@CacheLookup
		public WebElement firstName;
		
		public void setFirstName(String name) {
			firstName.sendKeys(name);
		}
		@FindBy(name="lname")
		@CacheLookup
		public WebElement lastName;

		public void setLastName(String name) {
			lastName.sendKeys(name);
		}
		
		@FindBy(name="email")
		@CacheLookup
		public WebElement email;
		public void setEmail(String mail) {
			email.sendKeys(mail);
		}
		
		@FindBy(name="mobile")
		@CacheLookup
		public WebElement mobileno;
		public void setMobileNo(String no) {
			mobileno.sendKeys(no);
		}
		
		@FindBy(name="D6")
		@CacheLookup
		public WebElement tutionType;
		public void selectTutionType(String tType) {
			tutionType.sendKeys(tType);
		}
		
		@FindBy(name="D5")
		@CacheLookup
		WebElement city;
		public void selectCity(String enteredCity) {
			city.sendKeys(enteredCity);
		}
		
		@FindBy(name="D4")
		@CacheLookup
		WebElement learningMode;
		public void selectLearningMode(String mol) {
			learningMode.sendKeys(mol);
		}
		
			
		@FindBy(id="enqdetails")
		@CacheLookup
		WebElement enquiryDetails;
		public void setenquiryDetails(String details) {
			enquiryDetails.sendKeys(details);
		}
		
		@FindBy(id="Submit1")
		@CacheLookup
		WebElement button;

		public void clickButton() {
			button.click();
		}

}


